﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-VDOVIB3\SQLEXPRESS04;Database=BookShop;Integrated Security=True;";
    }
}
