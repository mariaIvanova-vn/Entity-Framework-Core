﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.Common
{
    public static class GlobalConstants
    {
        //Employee
        public const int EMPLOYEE_USERNAME_MAX_LENGTH = 40;

        public const int EMPLOYEE_PHONE_MAX_LENGTH = 12;

        //Project
        public const int PROJECT_NAME_MAX_LENGTH = 40;

        //TASK
        public const int TASK_NAME_MAX_LENGTH = 40;
    }
}
