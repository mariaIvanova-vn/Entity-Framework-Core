﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Footballers
{
    public class GlobalConstants
    {
        //Footballer

    }
}
