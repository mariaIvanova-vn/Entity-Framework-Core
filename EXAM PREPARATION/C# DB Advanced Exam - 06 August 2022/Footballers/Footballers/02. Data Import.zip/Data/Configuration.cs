﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-VDOVIB3\SQLEXPRESS04;Database=Footballers;Trusted_Connection=True";
    }
}
