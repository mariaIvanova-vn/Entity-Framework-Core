﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Footballers
{
    public class GlobalConstants
    {
        public const string TEAM_NAME_REGEX = @"^[A-Za-z\d\. -]*$";
    }
}
