﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-VDOVIB3\SQLEXPRESS04;Database=Trucks;Trusted_Connection=True";
    }
}