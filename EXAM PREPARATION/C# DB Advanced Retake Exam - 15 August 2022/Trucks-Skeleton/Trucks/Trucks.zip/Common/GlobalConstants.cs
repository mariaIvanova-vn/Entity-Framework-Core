﻿
namespace Trucks.Common
{
    public class GlobalConstants
    {
        //Truck
        public const int TRUCK_RegistrationNumber_MAX_LENGTH = 8;
        public const int TRUCK_VINNUMBER_MAX_LENGTH = 17;
        public const int TRUCK_TankCapacity_MAX_LENGTH = 1420;
        public const int TRUCK_CargoCapacity_MAX_LENGTH = 29000;
    }
}
